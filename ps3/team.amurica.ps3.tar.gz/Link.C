#include "Link.h"

Link::Link(Webpage* source, Webpage* target)
{
	this->source = source;
	this->target = target;
}


Link::~Link(void)
{
}

Webpage* Link::getSource()
{

	return this->source;
}

Webpage* Link::getTarget()
{
	return this->target;
}
