#include "Webpage.h"

using namespace std;

class Link
{
public:
	// Constructor & Destructor
	Link(Webpage* source, Webpage* target);
	~Link(void);

	// Methods
	Webpage* getSource();
	Webpage* getTarget();

	bool visited;

private:
	Webpage* source;
	Webpage* target;
};

