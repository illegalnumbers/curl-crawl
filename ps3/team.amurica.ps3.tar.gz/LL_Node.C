#include "LL_Node.h"

void LL_Node::setNext(LL_Node* next)
{
  this->next = next;
}

void LL_Node::setPrevious(LL_Node* previous)
{
  this->previous = previous;
}

void LL_Node::setData(string data)
{
  this->data = data;
}

LL_Node* LL_Node::getNext()
{
  return next;
}

LL_Node* LL_Node::getPrevious()
{
  return previous;
}

string LL_Node::getData()
{
  return data;
}
